CANTACT INFO:

  

Senior Manager Curriculum and Adult Learning

- Joseph Robinson

-- [jrobinson@perscholas.org](mailto:jrobinson@perscholas.org)

  

Tech instructor

- Elisha Kadiri

--[ekadiri@perscholas.org](mailto:ekadiri@perscholas.org)

  

Career Coach

- Tamara Perry

-- [tperry@perscholas.org](mailto:tperry@perscholas.org)

  

Director, Customized Training & Instruction

- Marcial Cordon

--[mcordon@perscholas.org](mailto:mcordon@perscholas.org)

  

Senior Associate National Customized Admissions

*Admission Team

- Lauren Geraci

--[lgeraci@perscholas.org](mailto:lgeraci@perscholas.org)

Asistant

- Omar Pina

--[opina@perscholas.org](mailto:opina@perscholas.org)