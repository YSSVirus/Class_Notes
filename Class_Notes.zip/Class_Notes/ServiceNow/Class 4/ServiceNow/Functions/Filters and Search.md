A filter restricts what records appear in a list by providing a set of conditions each record must meet to be  
included in the list. 
A condition consists of the following parts.  
● ***Field***: Each field contains data from a particular column in the table. Selecting a reference field allows  
you to dot-walk to data from other tables.  
● ***Operator***: Each field type has its own set of valid operators. The operator determines if a value is  
needed.  
● ***Value***: Each field has its own set of valid values determined by the field type. Reference fields have  
access to auto-complete, and choice lists provide a list of options.  
● ***Grouping***: Each condition line is grouped with either an AND or OR connector. The filter requires all  
condition lines linked with an AND connector to be met. The filter separately evaluates each condition  
line linked with an OR connector.