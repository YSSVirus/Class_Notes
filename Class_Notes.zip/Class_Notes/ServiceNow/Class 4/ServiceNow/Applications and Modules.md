ServiceNow defines Application as, a collection of files and data that deliver a service and manage business processes and Modules are, children of application linking to other pages or records in the platform.  

For example, we have an “Incident” application, which has modules like “Create new” to create a new incident for any department in BookWorm ltd. “Open” module lists all the open incidents within BookWorm ltd. (This module may only be visible to system administrators).  

Similarly, there are other important applications like Problem,  
Change, Workflows, etc. and its respective modules like “Create  
New”, “Open”, “WorkFlow editor”, etc.

These are located in the application manager