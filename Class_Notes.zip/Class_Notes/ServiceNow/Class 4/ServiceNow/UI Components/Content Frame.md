  
  
Displays information such as lists, forms, homepages, and wizards.

