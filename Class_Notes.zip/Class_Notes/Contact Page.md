Omar Pina
opina@perscholas.org

(This will be updated with a full contact list when I finish the last 40 or so pages on day 1 (there slide heavy so alot of notes))