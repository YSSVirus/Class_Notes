1) What is the vision?  
Embrace the vision of the organization by interpreting the high-level business objectives.  
2) Where are we now?  
Assess the current status of the organization in an unbiased manner. Consider this the  
baseline, inclusive of the business, organization, people, process, and technology.  
3) Where do we want to be?  
Adapt the vision identified in step 1 into a list of priorities for improvement, manifesting it  
into manageable and attainable targets.  
4) How do we get there?  
Design the CSI plan for purposes of improvement, utilizing and improving ITSM processes.  
5) Did we get there?  
Verify the measurements and metrics that are in place and determine that milestones were  
achieved. Rate and measure the success rate of business objectives and priorities met.  
6) How do we keep the momentum going?  
As the approach is re-initiated, confirm that changes and improvements have been  
understood and applied. Use this pattern of success to maintain future momentum, as the  
CSI Approach begins anew.