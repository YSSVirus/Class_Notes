 Event  
 Alert  
 Incident  
 Problem  
 Service Request  
 Standard Change  
 Resolution  
 Workaround  
 Known Error  
 KEDB  
 Categorization