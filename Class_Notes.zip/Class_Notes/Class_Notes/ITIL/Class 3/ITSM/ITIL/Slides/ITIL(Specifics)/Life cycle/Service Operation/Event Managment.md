PURPOSE  
Monitor all events that occur through the IT infrastructure to allow for normal operation, as  
well as detect and escalate exceptions for handling resolution to the relevant roles.  
An event can be defined as any changed state that has significance for managing a CI or  
service. These changed states can be indicated through notifications created by a service, a CI,  
or an independent monitoring tool that polls CI for exceptions.  
Based on this view, this process could be considered the basis for operational monitoring and  
control in general. Sometimes, Event Management can be used as part of a system that triggers  
automated processes, like a script running on a remote device that reallocates system  
resources if usage limits are in danger of overrunning available resources.  
  
  
  
OUTPUT  
Event logs, completion alerts, and any other related event  
data.