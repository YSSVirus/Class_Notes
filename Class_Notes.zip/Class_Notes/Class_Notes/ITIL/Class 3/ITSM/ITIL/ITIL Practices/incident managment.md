purpose - 
the practice of minimizing the negative impact of incidents by restoring normal service operation as quickly as possible

inident - 
an unplanned inturruption to a service or reduction in the quality of a service