Some notes on Emergency changes:  
Emergency changes might need to sidestep typical Change Management workflows. The onus is on  
maintenance of a system that accounts for unforeseen circumstances, keeping emergency change proposals  
to an absolute minimum.  
As you might expect, emergency change procedures are often restricted to the repair of an error in an IT  
service of great negative impact to the business.  
Unlike normal change procedures, this often (but not always) involves founding an ECAB. The resultant  
decisions will lead to collaboration with the relevant IT managers to ensure that staff and resources are  
specifically routed