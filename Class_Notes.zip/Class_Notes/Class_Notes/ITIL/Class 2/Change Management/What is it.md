The purpose of change management process is to control the lifecycle of all changes, in turn enabling benificial changes to be made with minimal disruptions.

Change management is responsible for the coordination of a change, ensuring it goes smoothly, anticipating any changes and controlling risks

Proactive response