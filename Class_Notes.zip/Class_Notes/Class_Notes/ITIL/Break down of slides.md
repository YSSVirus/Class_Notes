Day ONE presentation:
Service Provider Types= Slides 84-88
Design Coordination= Slide 124
5 aspects of service design (STAMP)= Slide 135
4 Ps of service design= slide 137
Capacity mngmnt= Slide 140-143
Availability mngmnt= Slides 145-149
Info security mngmnt= Slides 154-157
SLA& OLA definitions= Slide 175

Day TWO presentation:
Sercive asset and configuration activities= Slide 11
Configuration item= Slide 12
Change/transition mngmnt= Slides 22-23
Change Types= Slides 24-28
7 Rs of Change mngmnt= Slide 28
Backout plan= slide 32
Knowledge mngmnt purpose= Slide 46
Release & deployment= Slide 53 & 54
4 phases of release and deployment= slide 57

Day THREE presentation:
Service operation= Slide 3
Core of ITIL= Slide 5
Event mngmnt= Slide 9-12
Incident management= Slide 26
Scope of incident/ major incident= Slides 28-29/ 30
Examples of incident priority & classification= Slides 34-36
Request fulfillment= Slide 45 (objective of R.F.) and Slide 46 (scope of R.F.)
Problem management objective and purpose= Slide 59-62
