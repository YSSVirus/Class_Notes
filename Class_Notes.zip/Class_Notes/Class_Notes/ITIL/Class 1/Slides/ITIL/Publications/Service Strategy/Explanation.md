Value is the core topic within service strategy. Processes covered within Service Strategy include the following:
• Strategy Management for IT Services  
• Business Relationship Management  
• Financial Management for IT Services  
• Service Portfolio Management  
• Demand Management


