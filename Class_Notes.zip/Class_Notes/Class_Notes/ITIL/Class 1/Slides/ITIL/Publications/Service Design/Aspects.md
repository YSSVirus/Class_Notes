1. Service solutions for new or changed services: The requirements for  
new or changed services, based on the service portfolio.  
2. Management information systems and tools: It is important that these  
be maintained in step with each individual service change or addition.  
3. Technology architectures and management architectures: Same as  
previous – if these do not function anymore in light of new services, they  
need to be updated.  
4. The main processes themselves: These will be introduced and discussed  
in greater detail soon.  
5. Measurement methods and metrics: Much like #2 and #3 above, these  
must be continuously reviewed to ensure that they are still applicable as  
services are changed.