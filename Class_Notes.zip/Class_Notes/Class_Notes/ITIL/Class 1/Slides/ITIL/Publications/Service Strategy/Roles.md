- ***Service Strategy Manager*** - 
Produces, implements, maintains the service provider’s strategy, including communicating details of the strategy to the ISG and other  
executive ITIL roles  

- ***IT Steering Group (ISG)*** -
Sets the direction and strategy for IT Services. Also prioritizes development of projects/programs and service additions.  

- ***Service Portfolio Manager*** - 
Develops the service provider’s offerings and capabilities, and  
prioritizes customer service strategy with the ISG  

- ***Financial Manager*** -
Manages the ABC’s:Accounting, Budgeting, and Charging  

- ***Demand Manager*** - 
Manages the Demand Management process, including anticipating,  
interpreting, and influencing customer demands for services.  

- ***Business Relationship Manager (BRM)*** -
Responsible for all major aspects of customer relations. Details in the  
Business Relationship Management slides.