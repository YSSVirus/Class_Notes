There are many risk management frameworks available for IT service providers to choose from. Most of these risk frameworks follow the activities as defined by international standard ISO/IEC 31000.  
These are activities are as follows:  
1. Identify risks in operations  
2. Analyzing and prioritizing risks  
3. Planning and scheduling risk actions  
4. Tracking and reporting risk  
5. Controlling risk  
6. Learning from risk