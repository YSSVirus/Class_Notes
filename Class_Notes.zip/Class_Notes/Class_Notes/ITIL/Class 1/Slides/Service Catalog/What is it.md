A database or structured document with information about all live IT services, including those available for deployment.  

The service catalog is part of the service portfolio and contains information about two types of IT service:  
1. Customer-facing services that are visible to the business;  
2. Supporting services required by the service provider to deliver customer-facing service
3. 