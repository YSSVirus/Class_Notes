**Paying for a service incurs the need for Warranty to be provided**, which can dictate which particular service is right for a customer. In service management, warranty is considered satisfactory if all 4 of the following conditions are met to a customer’s satisfaction:  
1) Availability of a service  
2) Capacity of a service  
3) Security of a service  
4) Continuity of a service  
These concepts often relate to each other, and relate to Utility as a whole as well. Additionally, it is important to keep in mind that not all services require maximum levels of the four conditions; they simply need to provide satisfactory conditions to the customer’s level of need.