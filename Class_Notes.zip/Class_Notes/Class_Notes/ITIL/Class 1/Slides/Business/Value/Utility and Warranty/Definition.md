There are two primary elements of value:  
***utility (fit for purpose)*** &  
***warranty (fit for use)***.  

**Both** of these elements must exist in order for the customer to realize value from the service. 

***==Utility==*** is the functionality offered by the service to meet a particular need, This is referenced to as being fit for purpose. 
***==Warranty==*** is the assurance that the service will meet its agreed requirements. Warranty is referred to as being fit for use.