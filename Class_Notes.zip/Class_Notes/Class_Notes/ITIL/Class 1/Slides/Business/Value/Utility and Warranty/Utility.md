Utility is typically achieved by 
- improving performance
- removing/reducing constraints
- or combining these two concepts. 
Constraints are restrictions, or represent an inability to execute  
an activity or task.  
If a client has an email marketing campaign they want to do, they could find and use a free email program to try and do this, but they will experience restrictions in the forms of limited amount of emails allowed, inability to see who opens them, and/or inability to effectively manage the multitude of emails to be sent.  
That customer may choose to employ an email marketing SaaS platform, which will allow them to manage the scheduling and reporting of their email campaigns. This example describes a service that improves performance (i.e. can schedule bulk email sends easily) and removes constraints (no limit on amount of emails sent, ability to track emails) probably among other marked benefits.