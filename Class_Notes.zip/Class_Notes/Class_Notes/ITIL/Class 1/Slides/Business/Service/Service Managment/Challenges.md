Services are of an intangible nature. 
The service itself may be difficult to measure or validate. 
Demand of the service is tightly coupled to the customer’s own assets. 

There is very little buffer between the service provider delivering the service and the customers consumption of that service. 

The service can be considered perishable, excess capacity when not required provides no value to the customer.