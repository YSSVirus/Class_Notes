Remember that the customer does not care about why a problem is happening, they just want it fixed so there business can continue as planned.

Part of providing a service is being able to supply the customer with no hassle


“without the ownership of specific costs and risks.”
***The customer does not want the management hassle of the infrastructure.***