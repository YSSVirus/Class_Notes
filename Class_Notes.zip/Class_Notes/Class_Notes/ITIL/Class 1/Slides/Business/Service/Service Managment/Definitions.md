***==Service management==***: How the service provider will organize to manage services. 
”Service Management is a set of specialized organizational capabilities for providing value to the customer in the form of services.” 

***==Functions==***: Groups of people and their tools. Process: A set of inter-related activities... The work that people do.

***==Process==***: A set of inter-related activities... The work that people do.