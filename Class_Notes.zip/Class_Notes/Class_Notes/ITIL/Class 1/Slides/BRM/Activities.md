Identify Service Requirements  
• Understanding and documenting the desired outcomes of a service and determine whether or not the service provider’s present service offerings can satisfy a customer’s needs.  
• If not, express the need for additional services to be added.  

Sign up Customers to Standard Services  
Obtain customers based on what the service provider is currently offering. Generally speaking, the focus here is on configuring current services to satisfy customer needs without having to provision new services.