• Availability Manager Defines, plans, analyzes, and measures aspects of availability for IT services.  
• Capacity Manager Ensures that IT services and infrastructure are able to consistently deliver capacity and performance targets as agreed in the SLA  
• Enterprise Architect Maintains the Enterprise Architecture  
• Information Security Manager Ensures the confidentiality, integrity and availability of an organization’s IT resources and services.  
• Service Catalog Manager Maintains the Service Catalog for accuracy and keeps it up to date.  
• Supplier Manager Ensures that value is being obtained from suppliers, and upholds contracts with suppliers to support the needs of the business