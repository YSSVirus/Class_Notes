- **People**  
People
- **Process**
Process
- **Products**
Technology  
- **Partners**
Suppliers