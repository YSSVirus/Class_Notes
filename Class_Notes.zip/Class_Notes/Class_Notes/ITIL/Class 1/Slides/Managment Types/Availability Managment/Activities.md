***Reactive***
- Monitoring services and components
- Reacting to incidents and problems that cause unavailability

***Proactive***
- Risk Assesment
- Implement cost justifiable counter measures
- Plan and design services
- Test availability and resiliency measures


***Design Services for Availability  ***
Design procedures and technical features to support and fulfill the agreed,  
expected availability levels.  
***Availability Testing  ***
Ensure that all availability, service resilience, and recovery mechanisms are  
actively tested and overseen.  
***Availability Monitoring and Reporting  ***
Provide other service management processes and IT management with  
information related to availability, fed and upheld by availability testing.