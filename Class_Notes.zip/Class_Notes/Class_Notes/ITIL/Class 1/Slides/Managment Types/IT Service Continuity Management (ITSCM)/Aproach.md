A lifecycle approach should be adopted to the setting up and operation of an ITSCM process  
• Revised ITSCM policy  
• Plan and strategy  
• ITSCM testing schedule  
• Test scenarios  
• Reports and reviews  
• Business Impact Analysis reporting