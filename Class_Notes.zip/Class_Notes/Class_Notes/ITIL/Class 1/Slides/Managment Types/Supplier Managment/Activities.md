- ***Definition of New Supplier and Contract Requirements  ***
Identify business needs (including internal/external options), costs, timescales, targets, benefits, and risk assessment.  
- ***Evaluation of New Suppliers and Contracts  ***
Identify methods to purchase, establish evaluation criteria, evaluate alternatives, and negotiate completion of contracts.  
- ***Supplier and Contract Categorization and Maintenance of SCMIS ***
Maintain the SCMIS, including assessment of suppliers and contracts.  
- ***Establishment of New Suppliers and Contracts  ***
Set up supplier services and contracts within SCMIS, process through Service Transition, and set up new contracts and relationships with suppliers.  
- ***Supplier, Contract, and Performance Management  ***
Manage operation and delivery of services/products, monitor, report, review, and improve, considering the 3 main factors to suppliers: Service, Quality, and Costs. This is also the sub-process wherein suppliers are considered for termination or renewal.  
- ***Contract Renewal or Termination***  
Review contracts to determine benefits of renewal or renegotiation, then proceed as necessary.