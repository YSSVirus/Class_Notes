To provide the strategic direction for security activities and ensure its objectives are achieved, with a special reliance on preventing information security breaches. ITIL makes a point that the term information being used in this respect is general, and includes data stores, databases, and metadata, not client/customer information alone. 
This main process is critical when regarding the warranty of a service – and thereby is perceived value. 
Security objectives can be considered met when:  
-Information confidentiality is kept  
-Information integrity is maintained  
-Information is available when required  
-Business transactions and information exchange between enterprises can be trusted