***Business Capacity Management  ***
Translate business needs and plans into capacity and  
performance requirements for services and IT  
infrastructure, with special attention on future needs.  
***Service Capacity Management  ***
Manage, control, and predict the capacity and  
performance of operational services.  
***Component Capacity Management  ***
Manage, control, and predict the capacity, performance,  
and application of a service provider’s IT resources and  
assets