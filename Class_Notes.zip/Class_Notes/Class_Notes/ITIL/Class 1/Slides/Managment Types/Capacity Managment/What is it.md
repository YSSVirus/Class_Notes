Capacity management considers all resources required  
to deliver the IT service, and plans for short-, medium-  
and long-term business requirements.