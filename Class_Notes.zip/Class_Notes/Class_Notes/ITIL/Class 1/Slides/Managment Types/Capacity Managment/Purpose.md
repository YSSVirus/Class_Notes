***Official*** – ensure that the capacity of IT services and the IT infrastructure meets the agreed capacity and performance-related requirements in a cost-effective and timely manner. Capacity management is concerned with meeting both the current and future capacity and performance needs of the business.  

***Unofficial*** – Plan & manage capacity.