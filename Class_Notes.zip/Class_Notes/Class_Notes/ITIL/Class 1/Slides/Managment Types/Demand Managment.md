PURPOSE  
• Demand Management is the process of interpreting, anticipating, and influencing customer demand for services.  
• This process works closely and directly with Capacity Management to ensure that the service provider can deliver the value that is being requested by the customer, and/or the market at-large.  

OUTPUT  
User profiles, PBAs, documentation of differentiated service offerings, and policies for how to deal with situations of demand