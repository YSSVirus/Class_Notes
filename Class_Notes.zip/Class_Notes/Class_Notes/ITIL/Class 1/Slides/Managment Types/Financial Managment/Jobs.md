Official – to secure the appropriate level of funding to  
design, develop and deliver services that meet the strategy of  
the organization. At the same time financial management for  
IT services is a gatekeeper that ensures that the service  
provider does not commit to services that they are not able to  
provide.  

Unofficial – Manage the Money. Budgeting, Accounting,  
Costing, Charging