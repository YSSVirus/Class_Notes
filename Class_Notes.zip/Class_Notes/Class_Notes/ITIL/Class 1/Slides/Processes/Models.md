Process Models allow varying levels of formality & intensity of an individual activity or a process.  
They allow the correct skill level to be applied to a set of activities without over-paying for the skill-set.  
A process model is, in effect, a pre-defined template:  
• Policies & Standards  
• Guidelines  
• Activities  
• Work Instructions & Sequence  
• Timescales and Thresholds  
• Escalations