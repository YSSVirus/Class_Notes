A set of activities, responsibilities, and/or authorities granted to/performed by a person, group or team.  
Roles define “who you are” at a particular moment in time.  
- Scope is defined in a process or a function  
- Individual may serve multiple roles  
- Authority and responsibility will be defined for a  
particular role.  
- There will be a defined specific performance  
expectation