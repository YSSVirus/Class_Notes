❏ Catalog item: is an individual record or item that describes a Product or service  
a user can order in the service catalog, and there are several different types:  
● The standard Catalog Item  
● An Order Guide  
● A Record Producer  
❏ The System Administrator and Catalog Manager Navigate to Service Catalog  
	→ Maintain Items to create new catalog item or edit a catalog item  
❏ End user can access Catalog item from Service portal or Self Service Dashboa