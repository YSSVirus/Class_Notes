❏ Tailor a Catalogue Item to the customer’s needs. Service catalog variables capture and pass on  
information about choices a customer makes when ordering a catalog item. Variables help define the  
structure of a catalog item form that is displayed to the customer.  
❏ For example, you can define a variable called Memory to provide users with memory options at an  
extra cost for a PC catalog item. An Apple iPhone catalog item can use a variable called Color that  
allows customers to select the color when they order the phone from the catalog. We can define  
some variables to affect an item price, depending on the choices made.  
❏ Variables Set: The variable set is basically the collection of variables. The benefits of variable set is  
that we can use created variable set across multiple catalogs item and order guides.  
❏ This basically saves time, because if have to create multiple catalogs item which contains some of  
same fields then there we can use the created variable sets. We can create the variable set contain  
variable which will be common between catalog items.