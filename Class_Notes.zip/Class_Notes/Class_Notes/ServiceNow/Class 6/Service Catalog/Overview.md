❏ Service Catalog – An ITIL service catalog is a listing of all IT services offered to the business. It allows users to browse or search the offerings and request them in the same manner as an online shopping experience.  
❏ The Service Request Catalog is split into two main parts – a shopping style interface (with a cart, items to order, and a more graphical interface than we've seen so far) and a fulfillment backend that uses workflow to control how the orders are processed.  
❏ Using ServiceNow, administrators and catalog administrators can define and manage  
multiple items and categories with in the multiple Service Catalog . When you navigate  
to Self Service → Service Catalog, you will see Catalog Items organized into categories.  
❏ The System Administrator and Catalog Manager navigates to Service Catalog > CatalogDefinitions > Maintain Catalogs, to can create a catalog