● ***Catalog Manager***: The catalog manager’s purpose is to ensure that changes to the service catalog are controlled and to provide a method for efficiently resolving service-catalog issues.  
● ***Service Owner***: Each service must have a designated owner. The service owner is accountable for the delivery of a specific IT service.  
● ***Requester***: Requesters may be anyone in the organization with access to make requests, and  
they may submit service requests on someone else’s behalf.  
● ***Approver***: Approvers are the line managers, service owners, and business stakeholders (such as financial managers) responsible for reviewing request details and granting approval or rejecting the requests. The actual number and types of approvals depend on the individual request.  
● ***Fulfiller***: Fulfillers are the people who are assigned to execute one or more specific tasks to


❏ Once you’ve submitted a request, you will need to route it to the catalog manager for review  and approval. When you are requesting a very complex service, you may not be able to  document every part of the requirement within the request itself, so the catalog manager may  
need to discuss the service in greater detail with the service owner.  
❏ Once the catalog manager is comfortable that the service is well understood and is appropriate  
to include in the catalog, they can approve the request. At this point, assign a task to a catalog  
editor to fulfill the request.