❏ The request management process immediately follows the submission of a request  
from the service catalog. It includes the approval of the overall request and/or the  
individually requested items and the subsequent fulfilment of them.  
❏ The request management process is triggered only when a catalog item from the  
Catalog Item [sc_cat_item] table is requested.  
❏ NOTE: A request (REQ) and a requested item (RITM) are not “assigned” to any group or  user. Only the task is. When all tasks are closed, the requested item is closed. When all  
requested items are closed, the request itself is closed.

Accordingly, there are three tables in ServiceNow service  
catalog for Request management:  
● The Requests table(REQ) [sc_request]  
● The Request ITem (RTIM) table [sc_req_item]  
● The tasks table [sc_task]  
All these tables are co-related and you can find these tables  
in the Service catalog application → Open records module.  
As shown below and next slide