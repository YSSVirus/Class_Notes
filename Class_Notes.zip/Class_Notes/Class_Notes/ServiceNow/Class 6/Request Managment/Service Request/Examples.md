]❖ AutoRepairPals.com Order: REQ0010001  
➢ RITM010012: Rotate Tires (No Approval Needed)  
■ SCTASK0010022: Rotate Tires (Group: Tire Rotators, Assigned To: Mike)  
➢ RITM010013: Oil Change (No Approval Needed)  
■ SCTASK0010023: Oil Change (Group: A+ Oil Change, Assigned To: John)  
➢ RITM010014: Transmission Replacement (Manager and Owner Approval Needed)  
■ SCTASK0010024: Order New Transmission (Group: Parts Department, Assigned  
To: Mark)  
■ SCTASK0010025: Transmission Removal (Group: Transmission Technicians L1,  
Assigned To: Dan)  
■ SCTASK0010026: Transmission Install (Group: Transmission Technicians L2,  
Assigned To: Ted)