This is at the top of every page

● User menu provides options to access your profile and preferences. Administrators can impersonate users and elevate their security role.  
● Connect sidebar icon: Lets you begin or continue conversations. This icon is available if Connect is enabled.  
● Global text search icon ():Finds records from multiple tables.  
● Help icon (): Opens the help panel with embedded help, where available. If there is no embedded help, it offers help search options.  
● Gear icon (): Opens the System settings for the user interface (UI) System settings for the user interface (UI).