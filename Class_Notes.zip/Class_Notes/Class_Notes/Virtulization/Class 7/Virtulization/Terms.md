Host
- This is your physical computer it is your main operating system that you boot into upon starting your computer. It is the true machine "running the show"

Virtual Machine
- This is the computer that is hosted within your computer (host).