The normal os uses a program called a supervisor
- It handles very low level interaction amoung hardware and software
