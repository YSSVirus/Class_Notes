IaaS - 
Infrostructre
As
a
Service

PaaS - 
Platform
as
a
Service

SaaS -
Software
as
a
Service