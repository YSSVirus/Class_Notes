Type 2
- Running virtual machine on a local system
- Simple form of virtulization
- Does not matter whether VM file itself is stored locally or centrally

Example: virtualbox