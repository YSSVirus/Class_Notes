Type 1
- Many of the servers we access today are virtulized
- A bare-metal hypervisor:
		- Installed without a host OS
		- No other software between it and the hardware (just bare metal)
- Industry refers to
		-
		-

Example: vmware vxi