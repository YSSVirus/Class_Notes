Cloud - Someone hosting Servers in some location given access through the internet.

Example: Amazon

Types - 
Public
Private
Community
Hybrid