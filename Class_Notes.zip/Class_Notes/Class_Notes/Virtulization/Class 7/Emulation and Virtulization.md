Emulator -
Uses the software to run a different platform

Virtulization -
Uses the Hardware to run a different Operating System