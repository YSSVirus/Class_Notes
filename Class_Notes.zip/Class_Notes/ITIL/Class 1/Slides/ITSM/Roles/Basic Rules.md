One person or team may have multiple roles.  

Example: the roles of configuration manager and change manager may be carried out by a single person.