IT service management (ITSM): “The implementation and management of quality IT services that meet the needs of the business.”  

IT service management is performed by an IT service provider managing services through a balanced mix of people, process and technology.