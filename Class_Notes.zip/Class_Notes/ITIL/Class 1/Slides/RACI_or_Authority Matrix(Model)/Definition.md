RACI - 
Responsible
- Who is responsible?
- The person who is **assigned** to the work

Accountable
- Who is accountable?
- The person who makes the** final decision** and has the **ultimate ownership**
 
Consulted
- Who is consulted?
- The person who must be **consulted ==before== a decision or action is taken**

Informed
- Who is informed?
- The person who must be** informed ==after== decision or action has taken place**