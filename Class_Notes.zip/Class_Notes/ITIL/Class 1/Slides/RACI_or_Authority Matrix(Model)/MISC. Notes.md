• ITIL embraces the RACI Matrix: Responsible, Accountable, Consulted, and  
Informed  
• The RACI Matrix in practice (also known as the RACI Model) greatly increases  
process efficiency and effectiveness, while minimizing redundancies across  
roles and responsibilities.  
• We will touch on the RACI Matrix when we discuss ITIL roles in greater detail.  
The main terms to become familiar with are Responsibility and Accountability  
– the majority of active roles in ITSM occupy these aspects often abbreviated  
to “R” or “AR”, depending on the particular role.