There are three types of service provider structures. These are referred to as the service provider types.  
***==Type I==*** service provider is an **internal** service provider  
- The type I service provider is an ***internal service provide*r**. The ***internal*** service provider provides services to only one customer. There can be many ***internal*** service providers in a single organization. Different business units within an organization may have their own ***internal*** IT department. This would be an example of multiple ***internal*** service providers, each providing services to a ***single customer***.

***==Type II==*** service provider is a **shared** services unit  
- ***Shared Services Unit*** The type II service provider is a*** shared*** services unit. The ***shared*** services unit provider deliver services to many internal customers. Each customer may have different needs and have a different SLA for their servicesShared Services Unit The type II service provider is a ***shared*** services unit. The ***shared*** services unit provider ***deliver services to many internal customers***. Each customer may have different needs and have a different SLA for their services

***==Type III==*** service provider is an **external** service provider
- The type III service provider is an ***external*** service provider. As the name  
suggests, an ***external*** service provider delivers IT services to ***external***  
customers. There will be a contract governing the delivery and payment  
of services.