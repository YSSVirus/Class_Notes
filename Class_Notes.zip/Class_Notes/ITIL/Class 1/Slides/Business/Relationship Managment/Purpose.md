Official –  
To establish and maintain a business relationship between the service provider and the  
customer based on understanding the customer and their business needs.  Unofficial – Collect information from the customer on needs, technology usage,  
and customer satisfaction.  
- Maintain the business relationship.  
- Identify changing customer needs