- **==internal customer==**
A customer who works for the same  
organization as the IT service provider.

- ==**external customer**==
A customer who works for a different  
organization from the IT service provider.