Success in Business means Management of a few key things especially Management of the following
• People  
• Process  
• Product

In management of People you have a few important things to think about.
• Right People  
• Skills  
• Attitudes  
• Culture  
• Best Practice Frameworks