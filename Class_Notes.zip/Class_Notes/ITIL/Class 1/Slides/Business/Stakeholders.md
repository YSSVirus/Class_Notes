Stakeholders is a very broad term can include:  
• shareholders that own part of the company  
• employees  
• customers  
• overall community that the organization operates in

Stakeholder **roles** and **definitions**.
- ***==Consumer==***  
The service consumer is the role  
that receives services from the  
service provider. The service  
consumer is a generic role that  
simply consumes the service.  
- ***==Customer==***  
A role that defines requirements for services  
and takes responsibility for outcomes from  
service consumption.  
- ***==User==***  
A role that uses services.  
- ***==Sponsor==***  
A role that authorizes the budget for service  
consumption.

Other Stakeholders can include:  
**==*Government Regulators  *==**
**==*Charity Organizations *==** 
**==*Community Organizations*==**
**==*Shareholders*==**
**==*Employees*==**