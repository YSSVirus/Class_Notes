- Complete set of services being managed by the Service Provider  
- All resources currently engaged or being released from the service lifecycle  
- Commitments and investments across all market spaces and segments  
- Links services to business needs  
- Describes services in terms of business value

The Service Portfolio is a tool to help understand where resources have been invested and if those investments are being profitable!
