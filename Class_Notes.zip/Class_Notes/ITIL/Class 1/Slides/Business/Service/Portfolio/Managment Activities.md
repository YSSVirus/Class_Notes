Define and Analyze new/changed services
- Define the outcomes desired for new/changed services, with attention to what will resources, and service assets will be needed for them, and how they will impact existing services.

Define the objectives of a proposed new/changed service
- Namely, how it might interreact with and impact the overall Service Portfolio, determine what will be needed to provide the service. 

Approve new/changed Services
- Mainly, this means the submission of a change proposal to Change Management. This sub-process is primarily concerned with overall service changes.

Service Portfolio Review
- Assess the Service Portfolio at regular intervals and keep it up perpetually up-to-date