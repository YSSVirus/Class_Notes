**City Water as a service**
"by facilitating outcomes customers want to achieve”  

1. I want water to drink,bathe, wash clothes, etc 
2. The service provider transports the water