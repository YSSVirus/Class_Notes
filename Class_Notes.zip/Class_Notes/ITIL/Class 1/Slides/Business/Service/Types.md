There are three categorizations for services:  

- ***==Core==: Represents and delivers the value by facilitating the desired business outcome.***
Example: Email
Example: Banking
Example: Book Publishing

- ***==Enabling==: Needed to deliver the core service. Network is a enabling service.***
Example: DNS
Example: Internet Banking
Example: Printing

- ***==Enhancing==: Value added to the core service. Not essential but has an excitement factor.***
Example: Phone enabled
Example: Online Bill Pay
Example: ebook Publishing