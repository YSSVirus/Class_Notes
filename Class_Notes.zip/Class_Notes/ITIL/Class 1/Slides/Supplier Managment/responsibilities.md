The Supplier Management process is responsible for obtaining value for money from suppliers as well as ensuring that all agreements with suppliers meet the needs of the business. The process also makes sure that suppliers meet their contractual commitments in a timely manner. A supplier is a third party responsible for  
supplying goods or services that are required  
to deliver IT services.

- Meet Goals  
- Ensure value for money  
- Process Consistency  
- Assist to review documents  
- Alignment with Corporate Supplier Strategies  
- Maintain & review data associated with SCMIS  
- Contractor agreement reviews  
- Monitor supplier performance