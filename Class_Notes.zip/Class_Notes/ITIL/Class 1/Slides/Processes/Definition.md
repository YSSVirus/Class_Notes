A process is a series of interrelated activities that transform inputs into desired outputs. Processes can be defined as structured sets of activities to a specific objective. 
- A process is a set of pre-defined activities seeking  
to achieve a pre-defined outcome.  

- Processes turn inputs into outputs.

Each of the 5 ITIL Lifecycle Stages contain a series of processes