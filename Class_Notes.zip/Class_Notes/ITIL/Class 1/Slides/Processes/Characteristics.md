**Measurable**  
- Cost  
- Quality  
- Performance

**Specific Results**
- Designed to produce a particular outcome  

**Customer**  
- Or beneficiary of the outcome  

**Trigger**  
-  Respond to specific events