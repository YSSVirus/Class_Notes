• Policies  
• Documentation  
• Governance  
• Metrics  
• Measuring success or failure  
• Defined Roles  
- Stakeholders  
- Roles vs Titles  
- Process Owner  
- Process Manager  
- Process Practitioner