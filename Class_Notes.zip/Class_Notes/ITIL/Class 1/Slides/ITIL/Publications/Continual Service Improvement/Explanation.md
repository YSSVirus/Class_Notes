The continual service improvement aligns and realigns the service portfolio to the ever- changing business needs of the customers. Improvement concepts covered within Continual Service Improvement include the following:  
• The Deming cycle: Plan-Do-Check-Act  
• CSI Approach  
• Metrics  
• Measurement  
• Assessments  
• Benchmarking  
• Governance