- Review, analyze, prioritize and make  
recommendations on improvement opportunities  
- Review and analyze service level achievement  
- Improve cost effectiveness of delivering IT  
services without sacrificing customer satisfaction  
- Ensure that processes have clearly defined  
objectives and measurements that lead to  
actionable improvements  
- Understand what to measure, why it is being  
measured