- Design Coordination Process  
- Service Level Management  
- Supplier Managment  
- Service Catalog Management  

***Warranty Processes *** 
- Availability Management  
- Capacity Management 
- IT Service Continuity Management
- Information Security Management

Warranty is the assurance that the service will meet its agreed requirements. Warranty is referred to as being fit for use.