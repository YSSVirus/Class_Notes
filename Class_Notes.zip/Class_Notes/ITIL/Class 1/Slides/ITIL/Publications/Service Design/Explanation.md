In Service Design, the strategy is developed into a plan to support the business objectives. Processes covered within Service Design include the following:  
• Design Coordination  
• Service Catalog Management  
• Service Level Management  
• Supplier Management  
• Availability Management  
• Capacity Management  
• IT Service Continuity Management  
• Information Security Management