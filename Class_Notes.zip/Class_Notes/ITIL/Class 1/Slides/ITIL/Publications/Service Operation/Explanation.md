Service operation is where the customer actually realizes (can benefit from) the value of the service. Processes covered within Service Operation include the following:
• Event Management  
• Incident Management  
• Request Fulfillment  
• Problem Management  
• Access Management  

Functions covered within Service Operation include the following:  
• Service Desk  
• Technical Management  
• IT Operations Management  
• Application Management