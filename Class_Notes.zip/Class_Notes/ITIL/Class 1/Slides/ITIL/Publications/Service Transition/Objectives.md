- Planning and managing service changes  
effectively  
- Managing risks related to services  
- Successfully deploying services into suited  
environments  
- Setting correct expectations on the  
performance of deployed services  
- Providing good-quality knowledge about  
services