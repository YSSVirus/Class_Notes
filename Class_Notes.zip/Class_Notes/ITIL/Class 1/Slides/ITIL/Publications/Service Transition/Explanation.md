The Service Transition lifecycle stage focuses on how to transition the organization from one state to another while minimizing risk and generating the greatest value at the same time. Processes covered within Service Transition include the following:
• Transition Planning & Support  
• Change Management  
• Service Asset & Configuration Management  
• Release & Deployment Management  
• Knowledge Management  
• Service Validation & Testing  
• Change Evaluation