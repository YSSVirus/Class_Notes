The objectives of Service Strategy include the following:  
- Helping the service provider understand strategy management  
- Development of the concept of a service and the creation of a  
service  
- To define value, and how value is created and realized by the  
customer  
- To identify opportunities for meeting desired customer outcomes.  
- To understand the capabilities required to support the strategy  
- The development of a service portfolio  
- Enable the service provider to develop an understanding of the  
level of investment and demand for services

**Another set of objectives is **
• To define the main goals and objectives of an organization,  
and outline a best-practice standard to guide it  
• To determine the quality measures of a project, in terms of  
effectiveness and efficiency over multiple targets  
• To articulate the particular services to be used in an  
organization, as well as outline the values to be delivered to  
its clients/customers  
• To assign roles and manage responsibility and  
accountability at the highest level  
• To design and manage the financial portfolio of a project  
• To define and position the project within its market  
environment