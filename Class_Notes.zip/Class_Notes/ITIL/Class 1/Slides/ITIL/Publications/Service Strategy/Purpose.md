”The purpose of Service Strategy is to define the perspective, position, plans and patterns that a service provider needs to be able to execute to meet in organizations business outcomes.”

The purpose of the Service Design Lifecycle stage is to: Design IT services, together with the governing IT practices, processes and polices to realize the service providers strategy.