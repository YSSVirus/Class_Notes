**==*strategy*==** -
a plan that outlines how an organization will  
meet a designed set of objectives and outperform  
competitors.  
**Purpose of Strategy?  **
*To Think and Act Strategically*