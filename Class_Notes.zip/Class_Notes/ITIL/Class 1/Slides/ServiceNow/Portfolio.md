Workload profiles describing the demand for an individual service or product or group of services and products. PBAs are an important tool used by Demand Management for anticipating and influencing service demand.

How does ITIL Service Strategy fit in this process?
 - **Idea** - 
Ideas are submitted and then evaluated to be accepted or rejected
- **Demand** - 
Demands are a customer’s want for a product or service.
- **Project** -
If approved a Demand can become a Project to create the value for the customer.