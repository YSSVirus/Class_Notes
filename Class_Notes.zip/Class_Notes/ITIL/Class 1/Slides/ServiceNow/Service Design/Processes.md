- Design Coordination Process  
- Service Level Management  
- Supplier Management  
- Service Catalog Management  
Warranty Processes  
- Availability Management  
- Capacity Management  
- IT Service Continuity Management  
- Information Security Management