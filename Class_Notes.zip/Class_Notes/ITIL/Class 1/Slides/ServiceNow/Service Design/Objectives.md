•The objective of service design is to design IT services so effectively that minimal improvement during their lifecycle will be required.  
•Continual improvement ensures that the service designs become even more effective over time  
•Identify changing trends in the business that may offer improvement opportunities