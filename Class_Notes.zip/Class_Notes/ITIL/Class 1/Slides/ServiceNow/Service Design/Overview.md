Service design will take a holistic view of the design of the service to include all aspects of the service necessary for that service to deliver the expected value to the customers. The five aspects of service design as part of this holistic approach include the following: (STAMP)  
• Service solution  
• Tools service management system  
• Architectures and standards  
• Metrics and measurements  
• Processes