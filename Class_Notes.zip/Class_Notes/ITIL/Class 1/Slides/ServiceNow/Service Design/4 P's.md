- **People**  
People
- **Process**
Process
- **Products**
Technology  
- **Products**
Suppliers