The purpose of the Service Design Lifecycle stage is to:  
Design IT services, together with the governing IT practices, processes and polices  
to realize the service providers strategy.  

