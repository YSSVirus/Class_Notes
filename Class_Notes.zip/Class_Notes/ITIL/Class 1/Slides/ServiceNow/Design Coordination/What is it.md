As part of design coordination, it is important that practices, documents, procedures or deliverables be integrated into the overall project management methodology and all project managers trained to contribute appropria

In terms of ITIL, one of the primary functions of this main process is to consider and plan out which IT resources will have to be leveraged, adapted, or created from the ground up when provisioning new services. Special consideration for a client’s experience will, as a result, be laid out in the Service Design Package (SDP). 

As with all things Service Design-related, special  
attention must be made for how each service change will  
affect the entirety of services  

OUTPUT  
Service Designs and SDPs. Revisions to enterprise  
architecture, management systems, measurements and  
metrics, and the service portfolio.

Active Roles In This Process:
- **Service Design Manager **
- **Project Manager  **
- **IT Operations Manager  **
- **Financial Manager**

