The purpose of the Design Coordination process is to ensure the goals of service design are met by providing and maintaining a single point of  
coordination and control for all activities and processes. The objectives of the Design Coordination process are to:  
• Ensure consistent design of appropriate services, tools,  
architectures, metrics & processes, to meet current  
and evolving business needs.  
• Coordinate all design activities across projects,  
suppliers and support teams, and manage conflicts,  
where required.  
• Plan and coordinate the resources and capabilities  
required to design new or changed services.  
• Produce service design packages (SDPs) based on  
service charters and change requests.