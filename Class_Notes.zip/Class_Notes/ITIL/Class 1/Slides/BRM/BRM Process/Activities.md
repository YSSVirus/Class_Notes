•Business outcomes that the customer wants to achieve.  
•How offered Services are being used by customer.  
•How services are being offered (responsibilities, agreed levels, quality,  
anticipated changes)  
•Expected impact of technology trends (customers affected and expected  
impact)  
•Customer satisfaction level  
•Future service optimization  
•Face of the service provider

Maintain Customer Relationships Ensure that the organization maintains an understanding of the customer’s needs, and develops relationships with new customers. Maintain the Customer Portfolio Update and maintain ownership of the Customer Portfolio

Customer Portfolio: a database or structured document used to record all customers of the IT Service Provider, representing the BRM’s entire view of an organization’s customers.