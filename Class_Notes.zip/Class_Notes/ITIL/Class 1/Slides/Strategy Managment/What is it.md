PURPOSE  
- Strategy management focuses on assessing the service provider’s offerings, capabilities, and available competitors, orienting its position within the market to develop a strategy to  serve customers. Top-level management responsible for this process ensures the implementation of a designed strategy and designates the roles who will carry it out.  

OUTPUT  
- Strategic and tactical plans, strategy review schedules, mission statements, vision statements, and strategic requirements for new services.