Strategic Service Assessment  
- Orient and position the service provider within its current market spaces. 

Service Strategy Definition  
- Define the overall goals and outcomes which the service provider should pursue in its development. Use the results of the strategic service assessment to identify the services which the project will use to create value. 
 
Service Strategy Execution  
- Define strategic initiatives and ensure that they are implemented.