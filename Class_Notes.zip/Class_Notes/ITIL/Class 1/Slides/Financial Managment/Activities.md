- ***Financial Management Support *** 
Outline the architecture that will manage financial planning data and allocate  
the cost of services  
- *** Financial Planning *** 
Plan the IT budget and project how it will be used over the next planning  
period. Ensure that it is efficiently applied to all services required.  
- ***Financial Analysis and Reporting *** 
Create a financial analysis, primarily used to support the Service Portfolio  
Management process.  
- ***Service Invoicing  ***
Creation and distribution of invoices to the customer