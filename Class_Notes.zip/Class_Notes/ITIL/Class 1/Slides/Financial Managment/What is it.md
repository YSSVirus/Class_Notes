PURPOSE  
This process is responsible for budgeting, accounting, and all fiscal aspects of an ITIL  
enterprise  
In many ways, this main process can be considered the most important part of the  
Service Strategy phase. Anticipating changes and pivoting throughout the service  
life-cycle is often tied directly to budgetary constraints.  

OUTPUT  
Service valuation, service investment analysis, compliance, cost optimization,  
Business Impact Analysis (BIA), and planning confidence