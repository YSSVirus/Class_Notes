ITIL stands for IT infrastructure library, it is a framework for IT business and service structuring designing and changing. used by most IT companies. Consists of 5 life cycles.

[What is a Service? ]
A Service is a means of delivering value to customers by facilitating outcomes customers want to achieve without the ownership of specific costs and risks. 

[What is Value?]
Value is the extent to which the service supports the customers desired business outcome. 

 [What is Utility vs. Warranty?]
Utility: 'Fit for purpose'/ The functionality offered by the service to meet a particular need
Warranty: 'Fit for use'/ The assurance that the service will meet its agreed requirements. 

[What is a Process? ]
A set of pre-defined activities seeking to achieve a pre-defined outcome. 
Processes turn inputs into outputs.

[What is a Stake holder?]
Broadly used term to represent anyone doing business with or in the company/Org

[What is a Role?]
A set of activities, responsibilities, and/or authorities granted to/performed by a person, group or team. 

"who you are at a certain/ particular moment"

Responsible
Accountable
Consulted
Informed

# [Service Strategy:] 
-Purpose is to define perspective,position, plans, and patters that a service provider needs to be able to execute to meet in organizations business outcomes.
-Scope:   *development of markets
				*service asset allocation/ROI
				*managing strategic risk
				*Implementing strategy
				*Organizational development
				*understanding value creation
Type 1 service provider is an internal service provider
Type 2 ' '  is a shared services unit. May have clients with different SLAs
Type 3 is an external service provider




# [Service Design:]
-Purpose of service is to design IT services, together with the governing IT practices, processes and polices to realize the service providers strategy.   The objective of service design is to design IT services so effectively that minimal improvement during their lifecycle will be required

The five aspects of service design as part of this holistic approach include the following: (STAMP)

•Service solution

•Tools service management system

•Architectures and standards

•Metrics and measurements 
  
*Processes

4 P's of service design: People, process, products, partners.

Design coordination process is to ensure the goals of service design are met by providing and maintaining a single point of coordination and control for all activities and processes. 


# [Service Transition:]
-Processes include
-Service Asset and configuration management
-Change management
-knowledge management
-Release and deployment management
-Service validation and testing
-transition planning and support
-Change evaluation

Types of change:
Normal- any change that is not a standard change or emergency change
Emergency change- a change that must be implemented as soon as possible to resolve a major incident
Standard change- Pre-authorized change that is low risk, relatively common, and follows procedure or instruction.


# [Service Operation:]
-Purpose of service operation is to Coordinate and carry out the activities and processes required to deliver and manage services at agreed levels to business users and customers.


"important Terms"
Event- A change of state has significance for the management of an IT service of other CI.  Events can require IT operations personnel to take action and often result in events being logged

Alert

Incident- an unplanned interruption to an IT service or reduction in the quality of an IT service. failure of a configuration item that has not yet affected service is also an incident.

Problem- A cause of one or more incidents the cause is not usually known at the time a problem record is created and the problem management process is responsible for further investigation.

Service request- formal request for something to be provided i.e. password reset

Standard change-

Resolution- solution to incident or problem

Workaround- a quick non temporary fix

Known error- A problem that has a documented root cause or a workaround

KEDB -



# [Continual Service Improvement:]






