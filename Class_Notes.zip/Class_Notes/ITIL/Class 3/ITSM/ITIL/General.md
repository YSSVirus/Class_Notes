This is a ITSM framework

SVS - 
Service
Value
System


ITIL has 34 different practices
5 listed (maybe most important)
go back through video 
https://www.youtube.com/watch?v=K1vPQjt7q-4
and get other 3

version 3 doesnt mention cyber attack
but cyber security handles attacks like ransomware and such