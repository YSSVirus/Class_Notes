•CSI Manager  
Measure performance and manage improvements to ITSM processes & services  
Designs the CSI Register  
Should positively influence all levels of management to ensure improvement activities are being supported  

•Reporting Analyst  
Participate in CSI and SLM meetings to ensure validity of reporting metrics  
Produce trends and feedback on trends  
Produce performance reports using OLA, SLAs, and improvement initiatives  

•Step Improvement  
Process Owner/Manager  
Carry out the generic process owner role for 7-step improvement  
Ensure 7-step improvement processes are being observed  
throughout service lifecycle  
Manager also helps maintain the CSI register, and coordinate  
interfaces between 7-step improvement process and other processes