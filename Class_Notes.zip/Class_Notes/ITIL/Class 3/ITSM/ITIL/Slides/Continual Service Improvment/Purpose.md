The purpose of the CSI stage of the lifecycle is  
to align IT services with changing business needs by identifying  
and implementing improvements to IT services that support  
business processes.