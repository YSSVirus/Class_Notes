Purpose - 
Coordinate and carry out the procces required to deliver and manage services at agreed levels to business users and customers

Objectives - 
Maintain business satisfaction and confidence in IT  
through effective and efficient delivery and support  of agreed IT servicesMinimize the impact of service outages on day-to-day business activities  Ensure that access to agreed IT services is only provided to those authorized to receive those  
services