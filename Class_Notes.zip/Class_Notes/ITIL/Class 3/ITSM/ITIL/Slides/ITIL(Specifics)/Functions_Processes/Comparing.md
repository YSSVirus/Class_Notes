Process vs Function  

A function is a team or group of  
people and the tools or other  
resources they use to carry out one or  
more processes or activities.  
Functions carry out one or more processes and activities.  
We must clearly define the roles and  
responsibilities required to undertake  
the processes and activities.


One activity could be performed by  
several teams or departments  
One department could perform several activities  
An activity could be performed by groups