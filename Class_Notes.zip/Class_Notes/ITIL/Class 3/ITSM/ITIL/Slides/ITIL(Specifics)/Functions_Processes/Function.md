A groups of people and tools performing activities across one or more processes.

Self Contained units with specialized skill-sets  
Perform specific types of work, but across processes  
Have their own specialized tool-sets and knowledge  
Have defined resources available to them  
Have their own capabilities  
Organized for specialization  
May direct the work of other Functions by following Process Directions  
Provide Structure and Stability