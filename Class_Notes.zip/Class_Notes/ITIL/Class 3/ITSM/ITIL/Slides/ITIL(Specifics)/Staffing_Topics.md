Service Desk Staffing Topics  
Staffing Levels  
Deciding on the number of staff is based on a number of factors including, but not limited to;  
customer service size and expectations, budget requirements, service level targets, size and  
complexity of the IT infrastructure and Service Catalog, and skill level needed.  
Skill Levels  
The level and range of skills to be required for an organizations Service Desk staff varies but is  
often determined by target resolution times (often outlined in an SLA), the complexity of the  
supported systems and services, and financial projections. Generally speaking, the shorter  
target times requested, the hight the skill level required in employees, and the higher the  
cost.  
Training  
Skill levels must be maintained and supported within an organization through ongoing  
training and awareness programs.

Staff Retention  
Recognition of staff achievements within their roles, reward packages, team-building  
exercise, and staff rotation and promotion are all methods to retain valuable employees.  
Super Users  
Super Users are individual users, who sometimes are appointed by organizations to act as  
liaison points with IT in general and the service desk in particular. Super Users are usually  
given some additional training and awareness and used as a conduit for communication  
between the Service Desk and a section of its user community at-large.