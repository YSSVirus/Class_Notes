Request Access  
Access or restriction is requested or granted through a variety of mechanisms, such as a formal service  
request, a request via the Request Fulfillment system, an RFC, or a prompt by a program or application.  
Verification  
A requesting user is verified for access and determined to have a legitimate requirement to use a system,  
commonly and most easily via a username/password. For more sensitive services further authentication  
may be required, such as two-stage, biometric, encryption device, security question, etc.  
Provide Rights  
Rather than determining access directly, Access Management executes the policies and regulations  
sourced from Service Strategy and Service Design, ideally through an automated method. This is also the  
stage in the process where role conflicts are observed, ensuring that access to a user does not have  
regulation contradictions.  
Check and Monitor Identity Status  
Observance of role changes in an organization, in order to provision access rights on an as-needed basis.  
Some relevant ones include; job change, dismissal, or disciplinary action.