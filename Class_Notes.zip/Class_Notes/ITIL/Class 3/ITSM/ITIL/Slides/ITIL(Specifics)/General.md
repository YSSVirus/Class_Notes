PURPOSE  
Provide technical expertise and overall management of the IT infrastructure. A  
critical aspect of this function is ensuring that the organization has access to  
the right type and level of human resources to manage technology, an  
aspiration which is aligned with the entire service lifecycle as a whole.  
Technical Management supports a variety of other processes across the service  
lifecycle (and Service Operations in particular), including Problem  
Management, Change Management, Event Management, and others, with a  
focus on maintaining any records databases with up-to-date information. This  
function is considered a component of IT Operations Management.