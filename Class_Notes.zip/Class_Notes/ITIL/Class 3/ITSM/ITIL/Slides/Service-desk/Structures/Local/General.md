Language and cultural or political differences  
Different time zones  
Specialized groups of users  
The existence of customized or specialized  
services that require specialist knowledge  
VIP/criticality status of users