•Combine two or more of their geographically  
dispersed service desks to provide a 24-hour  
follow-the-sun service  
•This can give 24-hour coverage at relatively low  
cost, as no desk has to work more than a single  
shift.