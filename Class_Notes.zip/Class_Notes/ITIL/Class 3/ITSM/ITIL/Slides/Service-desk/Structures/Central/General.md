More efficient and  
cost-effective,  
allowing fewer  
overall staff to deal  
with a higher  
volume of calls