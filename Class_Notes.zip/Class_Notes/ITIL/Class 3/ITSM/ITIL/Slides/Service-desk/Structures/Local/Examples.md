The Service Desk is located within or physically close to the user community if serves. Offers a visible presence, which  
is appreciated by some users, but is often an inefficient and expensive resource. Relevant in certain cases, especially  
for VIP clients or to mediate language, cultural, or political differences.  
Centralized Service Desk  
Multiple Service Desks can be merged into a single or smaller set of locations by centralizing staff, resulting in a  
reduced number of Service Desks overall. Benefits include the potential for few staff to deal with a higher volume of  
calls. Can be hybridized with a Local Service Desk as well.  
Virtual Service Desk  
Very common in the present day, the Virtual Service Desk leverages technological resources and the internet to give  
the impression of a Centralized Service Desk. It is very adaptable to offshoring, outsourcing, and working from home.  
However, consistency and maintaining uniformity to service quality can present a challenge.  
Follow The Sun  
Combining two or more geographically dispersed Service Desk (as described above) to provide 24-hour service to  
clients (hence, service that “follows the sun” across the globe).  
Specialized Service Desk Groups  
Some organizations may need to construct specialized groups of Service Desks based on particular IT services, VIP  
needs, and the routing of increased types of issues.