The service desk will be the single point of  
contact (SPOC) between IT and end-users  
for all operational issues.  
Dedicated staff are an important part for the  
delivery of IT Services  
Single point of Contact (SPOC)  
•Incidents  
•Escalation  
•Service Requests  
•Answers questions


SO Functions: Service Desk  
PURPOSE  
Responsible for a variety of service activities, often via phone calls, a web interface, or in  
response to automatically reported infrastructure events.  
The Service Desk is a vital component of an IT organization, regularly positioned as the Single  
Point of Contact (SPOC) for users of services. ITIL is very forward in stating that a good Service  
Desk can compensate for deficiencies elsewhere in an organization, and a poor one will make  
an otherwise effective organization look terrible.  
Outsourcing this function is a common present-day topic, but an in-house Service Desk will  
benefit from communication ease, higher quality response, and faster turnaround on  
customer/user requests.  
We will finish this chapter by looking at several different Service Desk topics.