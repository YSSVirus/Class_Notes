Purpose - 
Reducing the likelihood and impact of incidents by identifying actual and potential causes of incidents and managing work arounds and known errors

problem -
a cause or potential cause of prior, current or future incidents

workaround - 
a soulution that reduces or eliminates the impact of an incident or problem for which a full resolution is not yet available. Some workarounds reduce the likelihood of incidents.