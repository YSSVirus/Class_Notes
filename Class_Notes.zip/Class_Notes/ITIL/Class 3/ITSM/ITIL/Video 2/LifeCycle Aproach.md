Life cycle aproach

Frst Sep -
Service Strategy
Establishes an overall strategy for IT Services and ITSM

Second Step - 
Service Design
Establish solutions to meet requirments

Third Step -
Service Transition
Managing the transition through the lifecycle

Fourth Step - 
Service Operation
Day to Day Managment of IT Services