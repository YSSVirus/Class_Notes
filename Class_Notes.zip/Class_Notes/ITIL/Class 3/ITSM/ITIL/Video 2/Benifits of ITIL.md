Commitment to ongoing service quality

Ongoing improvment to service and supporting processes

Review and implement of appropriate business-focused service measures

ROI (Return on Investment)

VOI (Value on Investment

Continual improvment becomes part of "Business as Usual"