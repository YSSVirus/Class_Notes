EDS
Exxon
Federal Express
GE Capital
General Accident
J.D. Edwards & Company
KPMG
Legal & General Insurance
Merrill Lynch
Microsoft Corp
Oracle
Hewlett Packard
UK Post Office
Procter & Gamble
Remedy Corp.
Royal Mail
Scottish Provident
Shell
Standard Life Assurance
The Equitable Insurance Company

Just to name a few
