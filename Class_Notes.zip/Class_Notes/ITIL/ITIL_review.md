Flash Questions From Review:

1. What do customer perceptions and business outcome help to define? 
Value of a service

2. Rights management or identity management in diff organizations is also known as: 

Risk managment
access management

3. which process will regularly analyze data to identify trends?
 problem management
 
 4. which is a stakeholder?
 all
 
 5. which best defines roles and responsibility ?
 RACI
 
 6. knowledge management
 
 7. steps in handling a normal change?
deploy without coordination

8. value has 2 inputs

purpose is warranty

9. best def of definitive media library?

dml is secure library of media

10. which of the following reason why itil is succesful?
all

11. event management monutors all events that occur.

12. Granting access and rights is access management

13. strategy 

14. def of service?
SLA and OLA 

15. following fucntion responsible of data management?

16. continual service improvement

17. not a valid objective problem management?

one user

18. term for change that is pre authorized?

standard

19. four P's 

people process products and partners

20. coordinates and carries customer facing services

Service operation (where the action happens)

21. data evolves into actionable value?
DiKW

22. the 7 rs of change management?

7 steps of continual improvement approach
questions to ask when assesing changes

23.  the experinces context and reflection of dikw

knowledge

24. any change of state that is significant for management?

event

25. CSI ensures effectiveness is improved through through 
 True

26. plan do check act
Deming cycle

27. most useful in defining roles and responsibiites 
 RACI model

28. service operation is carrying uout services 

29. warranty is consideres satisfactory when
 capacity, security, availability

30. what is RACI model for?roles and responsibilities of processes

31. stakeholders useres supplies and A

32.  External customer is not part of same org
 
 33. d

34. not definition of incident?

35. Consult (RACI)

36. Roles people and groups

37. follow the moon

38. which is not a service lifecycle (definition)

39. B

40. which of these represent correct sequence of CSI approach?vision where 
