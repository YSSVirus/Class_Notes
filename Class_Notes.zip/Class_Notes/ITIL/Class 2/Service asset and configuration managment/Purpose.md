ensure that the assets required to deliver  
services are properly controlled, and that accurate and  
reliable information about those assets is available when  
and where it is needed. This information includes details of  
how the assets have been configured and the relationships  
between assets.


Unofficial – Manage the accuracy of a CMDB to ensure  
understanding of the relationship of configuration items to  
each other for the delivery of services.