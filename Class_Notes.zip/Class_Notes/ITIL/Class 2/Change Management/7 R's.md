The following is extracted from the official ITIL Service Transition manual.  
These questions must be answered for ALL changes:  
1) Who raised the change?  
2) What is the reason for the change?  
3) What is the return required for the change?  
4) What are the risks involved in the change?  
5) What resources for the build, test, and implementation of the change?  
6) Who is responsible for the build, test, and implementation of the change?  
7) What is the relationship between this change and other changes?