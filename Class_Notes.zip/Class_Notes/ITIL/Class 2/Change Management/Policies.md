 All tests must be designed and carried out by  
people who have not been involved in the design  
of the service  
 Test pass/fail criteria must be documented in the  
SDP before testing begins  
 Test library and re-use policy. IT management  
thrives from re-use  
 Integrate testing into the project and service lifecycle  
 Adopt a risk-based testing approach aimed at  
reducing risk  
 Engage with customers, users and stakeholders to  
enhance their testing skills  
 Establish test measurements and monitoring systems  
 Automate as much as possible