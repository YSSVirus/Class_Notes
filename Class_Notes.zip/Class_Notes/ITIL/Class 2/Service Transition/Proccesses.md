Service Asset & Configuration Management  
Change Management  
Service Validation & Testing  
Knowledge Management  
Release & Deployment Management  
Transition Planning & Support  
Change Evaluation