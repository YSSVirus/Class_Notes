• Change Advisory Board (CAB) A group who advises the Change Manager, sourced from  
varies departments in the IT organization, and even inclusive  
of third parties.  
• Change Manager Manages the lifecycle of all changes and mediates significant  
changes to the CAB.  
• Knowledge Manager Ensures that the IT organization and service provider has  
access to, and can share, knowledge and information.  
• Release Manager Manages and plans releases between environments, and  
maintains the integrity of the live environment.