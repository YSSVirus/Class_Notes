Service now is a "ITSM" tool
I
T
Service
Managment

Another word for this is ticketing system
